-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Gép: 127.0.0.1
-- Létrehozás ideje: 2025. Már 17. 23:24
-- Kiszolgáló verziója: 10.4.28-MariaDB
-- PHP verzió: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Adatbázis: `kigyo`
--

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `fiókok`
--

CREATE TABLE `fiókok` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `felhasználónév` varchar(255) NOT NULL,
  `jelszó` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_hungarian_ci;

--
-- A tábla adatainak kiíratása `fiókok`
--

INSERT INTO `fiókok` (`id`, `email`, `felhasználónév`, `jelszó`) VALUES
(2, 'kpatyi0101@gmail.com', 'Kpatyi1', 'Jelszo12'),
(3, 'kpatyi0101@gmail.com', 'Kpatyi2', 'Jelszo12'),
(4, 'kpatyi0101@gmail.com', 'Kpatyi3', 'Jelszo12'),
(6, 'kpatyi0101@gmail.com', 'Kpatyi4', 'Jelszo12'),
(7, 'kpatyi0101@gmail.com', 'Kpatyi', 'Jelszo12');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `pontok`
--

CREATE TABLE `pontok` (
  `id` int(11) NOT NULL,
  `pont` int(11) NOT NULL,
  `kategória` varchar(255) NOT NULL,
  `nehézség` varchar(255) NOT NULL,
  `f_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_hungarian_ci;

--
-- A tábla adatainak kiíratása `pontok`
--

INSERT INTO `pontok` (`id`, `pont`, `kategória`, `nehézség`, `f_id`) VALUES
(3, 31, 'sebesség', 'normál', 4),
(4, 30, 'sebesség', 'normál', 7),
(5, 35, 'sebesség', 'nehéz', 7);

--
-- Indexek a kiírt táblákhoz
--

--
-- A tábla indexei `fiókok`
--
ALTER TABLE `fiókok`
  ADD PRIMARY KEY (`id`);

--
-- A tábla indexei `pontok`
--
ALTER TABLE `pontok`
  ADD PRIMARY KEY (`id`),
  ADD KEY `f_id` (`f_id`);

--
-- A kiírt táblák AUTO_INCREMENT értéke
--

--
-- AUTO_INCREMENT a táblához `fiókok`
--
ALTER TABLE `fiókok`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT a táblához `pontok`
--
ALTER TABLE `pontok`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Megkötések a kiírt táblákhoz
--

--
-- Megkötések a táblához `pontok`
--
ALTER TABLE `pontok`
  ADD CONSTRAINT `pontok_ibfk_1` FOREIGN KEY (`f_id`) REFERENCES `fiókok` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
