const http = require('http');
const fs = require('fs');
const path = require('path');
const mysql = require('mysql2');
const querystring=require("querystring");
const nodemailer = require('nodemailer');
const port = 3000;
const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'kigyo'
});
let e_kod=""
let adatok;
const server = http.createServer((req, res) => 
{
    switch(decodeURIComponent(req.url))
    {
        case "/kod":
            req.on("data",adat=>
            {
                const {kod}=querystring.parse(adat.toString());
                if(kod==e_kod)
                {
                    res.end("egyezik");
                }
                else
                {
                    res.end("nem egyezik");
                }
            });
            break;

        case "/ellenorzes":
            req.on("data",adat=>
            {
                const {felhasznalonev}=querystring.parse(adat.toString());
                connection.query('SELECT * FROM fiókok WHERE felhasználónév = ?',[felhasznalonev], (err,results) => 
                {
                    if(err)
                    { 
                        return res.end('Hiba történt: ' + err);
                    }
                    res.end(JSON.stringify(results));
                });
            });
            break;
        case "/belepes":
            res.end(JSON.stringify(adatok));
            break;
        case "/bejelentkezes":
            req.on("data",adat=>
            {
                const {felhasznalonev,jelszo}=querystring.parse(adat.toString());
                connection.query('SELECT email,felhasználónév,jelszó FROM fiókok WHERE felhasználónév = ? AND jelszó=?',[felhasznalonev,jelszo], (err,results)=>
                {
                    if(err)
                    { 
                        return res.end('Hiba történt: ' + err);
                    }
                    adatok=results[0];
                    res.end(JSON.stringify(results));
                });
            });
            break;
        case "/kijelentkezes":
            adatok=null;
            res.end("Főoldal.html");
            break;
        case "/mentes":
            req.on("data",adat=>
            {
                const{felhasznalonev,pont,kategoria,nehezseg}=querystring.parse(adat.toString());
                connection.query("SELECT id FROM fiókok WHERE felhasználónév= ?",[felhasznalonev],(err,results)=>
                {
                    if(err)
                    {
                        return res.end('Hiba történt: ' + err);
                    }
                    let id=results[0].id;
                    connection.query("INSERT INTO pontok (pont,kategória,nehézség,f_id) VALUES(?,?,?,?)",[pont,kategoria,nehezseg,id],(err)=>
                    {
                        if(err)
                        {
                            return res.end('Hiba történt: ' + err);
                        }
                        res.end("Sikeres mentés");
                    });
                });
            });
            break;
        case "/listazas":
            req.on("data",adat=>
            {
                const{kategoria,nehezseg}=querystring(adat.toString());
                if(kategoria=="0" && nehezseg!="0")
                {
                    connection.query("SELECT felhasználónév,pont,kategória,nehézség FROM fiókok,pontok WHERE f_id=fiókok.id AND pont=(SELECT MAX(pont) FROM fiókok,pontok WHERE f_id=fiókok.id) and nehézség=?")
                }
            });
            break;
        default:
            if(decodeURIComponent(req.url)=="/Email ellenőrzés.html")
            {
                req.on("data",adat=>
                {
                    let {email}=querystring.parse(adat.toString());
                    adatok=querystring.parse(adat.toString());
                    e_kod="";
                    for(let i=0;i<3;i++)
                    {
                        e_kod+=Math.floor(Math.random()*10);
                    }
                    
                    let transporter = nodemailer.createTransport(
                    {
                        service: 'gmail',
                        auth: 
                        {
                            user: 'kpatyi0202@gmail.com',
                            pass: 'dacq dsrv rwth qato'
                        },
                        tls: 
                        {
                            rejectUnauthorized: false
                        }
                    });
                    
                    let mailOptions = 
                    {
                        from: 'kpatyi0202@gmail.com',
                        to: email,
                        subject: 'Email cím ellenőrző kód',
                        text: 'A kódod: '+e_kod
                    };
                    
                    transporter.sendMail(mailOptions, function(error, info)
                    {
                        if (error) 
                        {
                            console.log(error);
                        } 
                        else 
                        {
                            console.log('Email sent: ' + info.response);
                        }
                    });
                });
            }
            let filePath;
            if(decodeURIComponent(req.url)=="/Főoldal.html" || req.url=="/" || decodeURIComponent(req.url)=="/Játék.html")
            {
                if(adatok!=null)
                {
                    if(decodeURIComponent(req.url)=="/Főoldal.html" || req.url=="/")
                    {
                        filePath= path.join(__dirname, 'public',"/Főoldal2.html");
                    }
                    else
                    {
                        filePath= path.join(__dirname, 'public',"/Játék2.html");
                    }
                }
                else
                {
                    filePath= path.join(__dirname, 'public', req.url === '/' ? 'Főoldal.html' : decodeURIComponent(req.url));
                }
            }
            else
            {
                filePath=path.join(__dirname, 'public',decodeURIComponent(req.url));
            }
            const extName = path.extname(filePath);
            // Tartalom típusa meghatározása
            let contentType = 'text/html';
            switch (extName) 
            {
                case '.css':
                    contentType = 'text/css';
                    break;
                case '.js':
                    contentType = 'application/javascript';
                    break;
            }
        
            // Fájl olvasása és kiszolgálása
            fs.readFile(filePath, (err, content) => 
            {
                if (err) 
                {
                    if (err.code === 'ENOENT') 
                    {
                        res.writeHead(404, { 'Content-Type': 'text/plain' });
                        res.end('Az oldal nem található!');
                    } 
                    else 
                    {
                        res.writeHead(500, { 'Content-Type': 'text/plain' });
                        console.log(err);
                        console.log(filePath);
                        res.end('Szerverhiba!');
                    }
                } 
                else 
                {
                    res.writeHead(200, { 'Content-Type': contentType });
                    res.end(content);
                }
            });
            break;
    }
});

server.listen(port, () => {
    console.log(`Szerver fut: http://localhost:${port}`);
});