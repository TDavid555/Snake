const http = require('http');
const fs = require('fs');
const path = require('path');
const mysql = require('mysql2');
const querystring=require("querystring");
const nodemailer = require('nodemailer');
const { kill } = require('process');
const { finished } = require('stream');
const port = 3000;
const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'kigyo'
});
let adatok1;
let adatok;
let e_kod;
const server = http.createServer((req, res) => 
{
    let filePath;
    switch(decodeURIComponent(req.url))
    {
        case"/listazas":
            req.on("data",adat=>
            {
                const{kategoria,nehezseg}=querystring.parse(adat.toString());
                connection.query("SELECT felhasználónév,pont FROM fiókok,pontok WHERE kategória=? AND nehézség=? AND f_id=fiókok.id ORDER BY pont DESC LIMIT 10",[kategoria,nehezseg],(err,results)=>
                {
                    if(err)
                    {
                        return res.end("Hiba történt: "+err);
                    }
                    res.end(JSON.stringify(results));
                })
            })
            break;
        case "/ellenorzes":
            req.on("data",adat=>
            {
                const{felhasznalonev}=querystring.parse(adat.toString());
                connection.query("SELECT * FROM fiókok WHERE felhasználónév=?",[felhasznalonev],(err,results)=>
                {
                    if(err)
                    {
                        return res.end("Hiba történt: "+err);
                    }
                    res.end(JSON.stringify(results))
                })
            });
            break;
        case "/mentes":
            req.on("data",adat=>
            {
                const{pont,kategoria,nehezseg}=querystring.parse(adat.toString());
                connection.query("SELECT * FROM fiókok WHERE felhasználónév=?",[adatok.felhasználónév],(err,results)=>
                {
                    if(err)
                    {
                        return res.end("Hiba történt: "+err);
                    }
                    let id=results[0].id;
                    connection.query("SELECT pont FROM pontok WHERE f_id=? AND kategória=? AND nehézség=?",[id,kategoria,nehezseg],(err,results2)=>
                    {
                        if(err)
                        {
                            return res.end("Hiba történt: "+err)
                        }
                        if(results2.length==0)
                        {
                            connection.query("INSERT INTO pontok(pont,kategória,nehézség,f_id) VALUES(?,?,?,?)",[pont,kategoria,nehezseg,id],(err)=>
                            {
                                if(err)
                                {
                                    return res.end("Hiba történt: "+err)
                                }
                                res.end("Sikeres mentés");
                            });
                        }
                        else
                        {
                            if(pont>results2[0].pont)
                            {
                                connection.query("UPDATE pontok SET pont=? WHERE kategória=? AND nehézség=? AND f_id=?",[pont,kategoria,nehezseg,id],(err)=>
                                {
                                    if(err)
                                    {
                                        return res.end("Hiba történt: "+err)
                                    }
                                    res.end("Sikeres mentés");
                                });
                            }
                            else
                            {
                                res.end("A mentet pont nem lehet kisebb mint a meglévő");
                            }
                        }
                    });
                })
            });
            break;
        case "/torles":
            connection.query("SELECT * FROM `fiókok` WHERE felhasználónév=?",[adatok.felhasználónév],(err,results)=>
            {
                if(err)
                {
                    return res.end("Hiba történt: "+err);
                }
                let id=results[0].id;
                connection.query("DELETE FROM pontok WHERE f_id=?",[id],(err)=>
                {
                    if(err)
                    {
                        return res.end("Hiba történt: "+err);
                    }
                });

                connection.query("DELETE FROM fiókok WHERE id=?",[id],(err)=>
                {
                    if(err)
                    {
                        return res.end("Hiba történt: "+err);
                    }
                    adatok=null;
                    res.end("Törlés")
                });
            });
            break;
        case "/bejelentkezes":
            req.on("data",adat=>
            {
                const{felhasználónév,jelszó}=querystring.parse(adat.toString());
                connection.query("SELECT * FROM fiókok WHERE felhasználónév=? AND jelszó=?",[felhasználónév,jelszó],(err,results)=>
                {
                    if(err)
                    {
                        return res.end("Hiba történt: "+err);
                    }
                    adatok=results[0];
                    res.end(JSON.stringify(results));
                })
            })
            break;
        case "/adatok":
            connection.query("SELECT * FROM `fiókok` WHERE felhasználónév=?",[adatok.felhasználónév],(err,results)=>
            {
                if(err)
                {
                    return res.end("Hiba történt: "+err);
                }
                let id=results[0].id;
                req.on("data",adat=>
                {
                    const{kategoria,nehezseg}=querystring.parse(adat.toString());
                    connection.query("SELECT pont FROM pontok WHERE f_id=? AND kategória=? AND nehézség=?",[id,kategoria,nehezseg],(err,results2)=>
                    {
                        if(err)
                        {
                            return res.end("Hiba történt: "+err);
                        }
                        let egesz=[Object.assign(results[0],results2[0])]
                        res.end(JSON.stringify(egesz));
                    })
                })
            });
            break;
        case "/kijelentkezes":
            adatok=null;
            res.end("Kilépés")
            break;
        case "/kod":
            req.on("data",adat=>
            {
                const{kod,oldal}=querystring.parse(adat.toString());
                if(e_kod==kod)
                {
                    if(oldal=="Regisztrálás")
                    {
                        adatok=adatok1;
                        connection.query("INSERT INTO fiókok(email,felhasználónév,jelszó) VALUES(?,?,?)",[adatok.email,adatok.felhasználónév,adatok.jelszó]);
                    }
                    if(oldal=="Szerkesztés")
                    {
                        connection.query("SELECT id FROM fiókok WHERE felhasználónév=?",[adatok.felhasználónév],(err,results)=>
                        {
                            if(err)
                            {
                                return res.end("Hiba történt: "+err);
                            }
                            let id=results[0].id;
                            connection.query("UPDATE fiókok SET email=?,felhasználónév=?,jelszó=? WHERE id=?",[adatok1.email,adatok1.felhasználónév,adatok1.jelszó,id],(err)=>
                            {
                                if(err)
                                {
                                    return res.end("Hiba történt: "+err);
                                }
                                adatok=adatok1;
                            });
                        });
                    }
                    res.end("Egyezik");
                }
                else
                {
                    res.end("Nem Egyezik");
                }
            });
            break;
        default:
            if(adatok==null)
            {
                if(decodeURIComponent(req.url)=="/Fiók szerkesztés.html")
                {
                    filePath=path.join(__dirname, 'public',"Főoldal.html");
                }
                else
                {
                    filePath=path.join(__dirname, 'public', req.url === '/' ? 'Főoldal.html' : decodeURIComponent(req.url));
                }
                if(decodeURIComponent(req.url)=="/Email ellenőrzés.html")
                {
                    Email_kuldes(req);
                }
            }
            else
            {
                const felosztas=path.parse(decodeURIComponent(req.url)).name;
                switch(felosztas)
                {
                    case "Játék":
                        filePath=path.join(__dirname,'public',"Játék2.html")
                        break;
                    case "Főoldal":
                        filePath=path.join(__dirname,'public',"Főoldal2.html")
                        break
                    case "/":
                        filePath=path.join(__dirname,'public',"Főoldal2.html");
                        break;
                    case "Email ellenőrzés":
                        filePath=path.join(__dirname,'public',"Email ellenőrzés2.html");
                        Email_kuldes(req);
                        break;
                    default:
                        filePath=path.join(__dirname, 'public',decodeURIComponent(req.url));
                }
            }
            const extName = path.extname(filePath);
            let contentType = 'text/html';
            switch (extName) 
            {
                case '.css':
                    contentType = 'text/css';
                    break;
                case '.js':
                    contentType = 'application/javascript';
                    break;
            }
                // Fájl olvasása és kiszolgálása
            fs.readFile(filePath, (err, content) => 
            {
                if (err) 
                {
                    if (err.code === 'ENOENT') 
                    {
                        res.writeHead(404, { 'Content-Type': 'text/plain' });
                        res.end('Az oldal nem található!');
                    } 
                    else 
                    {
                        res.writeHead(500, { 'Content-Type': 'text/plain' });
                        console.log(err);
                        console.log(filePath);
                        res.end('Szerverhiba!');
                    }
                } 
                else 
                {
                    res.writeHead(200, { 'Content-Type': contentType });
                    res.end(content);
                }
            });
            break;
    }

});
server.listen(port, () => {
    console.log(`Szerver fut: http://localhost:${port}`);
});

function Email_kuldes(req)
{
    req.on("data",adat=>
    {
        let {email}=querystring.parse(adat.toString());
        let kod="";
        for(let i=0;i<3;i++)
        {
            kod+=Math.floor(Math.random()*10);
        }
        let transporter = nodemailer.createTransport(
        {
            service: 'gmail',
            auth: 
            {
                user: 'kpatyi0202@gmail.com',
                pass: 'dacq dsrv rwth qato'
            },
            tls: 
            {
                rejectUnauthorized: false
            }
        });
        
        let mailOptions = 
        {
            from: 'kpatyi0202@gmail.com',
            to: email,
            subject: 'Email cím ellenőrző kód',
            text: 'A kódod: '+kod
        };
        
        transporter.sendMail(mailOptions, function(error, info)
        {
            if (error) 
            {
                console.log(error);
            } 
            else 
            {
                console.log('Email sent: ' + info.response);
            }
        });
        adatok1=querystring.parse(adat.toString());
        e_kod=kod
    });
}