let utkozott = false;
let irany;
let indulas;
let pont = 0;
let test = [];
let fejMozgasok = [];

function inditas(event) {
    if (irany == null && event.key != "ArrowLeft") {
        irany = event.key;
    } else {
        if (irany != event.key) {
            if (
                (irany == "ArrowLeft" && event.key != "ArrowRight") ||
                (irany == "ArrowRight" && event.key != "ArrowLeft") ||
                (irany == "ArrowUp" && event.key != "ArrowDown") ||
                (irany == "ArrowDown" && event.key != "ArrowUp")
            ) {
                irany = event.key;
            }
        }
    }
    clearInterval(indulas);
    indulas = setInterval(mozgas, 215);
}

function mozgas() {
    let kigyo = document.getElementById("kigyo");
    let kaja = document.getElementById("kaja");
    let x = parseInt(kigyo.getAttribute("x"));
    let y = parseInt(kigyo.getAttribute("y"));
    let kaja_x = parseInt(kaja.getAttribute("x"));
    let kaja_y = parseInt(kaja.getAttribute("y"));
    let lepes = 50;

    if (!utkozott) {
        fejMozgasok.unshift({ x, y });

        if (irany == "ArrowLeft") {
            x -= lepes;
            kigyo.setAttribute("href", "Képek/leftmouth.gif");
        } else if (irany == "ArrowRight") {
            x += lepes;
            kigyo.setAttribute("href", "Képek/rightmouth.gif");
        } else if (irany == "ArrowUp") {
            y -= lepes;
            kigyo.setAttribute("href", "Képek/upmouth.gif");
        } else if (irany == "ArrowDown") {
            y += lepes;
            kigyo.setAttribute("href", "Képek/downmouth.gif");
        }

        kigyo.setAttribute("x", x);
        kigyo.setAttribute("y", y);

        if (test.length > 0) {
            for (let i = 0; i < test.length; i++) {
                let resz = test[i];
                let ujpozicio = fejMozgasok[i]; //ne rakja a fejre
                if (ujpozicio) {
                    resz.setAttribute("x", ujpozicio.x);
                    resz.setAttribute("y", ujpozicio.y);
                }
            }
        }

        if (x == kaja_x - 10 && y == kaja_y) {
            pont++;
            let hely_y = Math.round(Math.random() * 650);
            let hely_x = Math.round(Math.random() * 750);
            while (hely_y % 50 != 0 || hely_x % 50 != 0) {
                hely_y = Math.round(Math.random() * 650);
                hely_x = Math.round(Math.random() * 750);
            }
            kaja.setAttribute("x", hely_x + 10);
            kaja.setAttribute("y", hely_y);
            document.getElementById("pont").innerHTML = pont;

            //+testrész
            let testResz = document.createElementNS("http://www.w3.org/2000/svg", "image");
            testResz.setAttribute("href", "Képek/test.gif");
            let kezdetipozicio = fejMozgasok[test.length + 1];//megoldás a repülésre. másra nem jó
            if (kezdetipozicio) {
                testResz.setAttribute("x", kezdetipozicio.x);
                testResz.setAttribute("y", kezdetipozicio.y);
            } else {
                testResz.setAttribute("x", x);
                testResz.setAttribute("y", y);
            }
            document.getElementById("palya").appendChild(testResz);
            test.push(testResz);
        }

        for (let i = 0; i < test.length; i++) {
            let resz = test[i];
            let reszX = parseInt(resz.getAttribute("x"));
            let reszY = parseInt(resz.getAttribute("y"));
            if (x == reszX && y == reszY) {
                utkozott = true;
                alert("Vége");
                break;
            }
        }

        if (x < 0 || x > 750 || y < 0 || y > 650) {
            utkozott = true;
            alert("Vége");
        }
    }
}
