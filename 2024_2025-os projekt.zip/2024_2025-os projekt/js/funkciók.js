let utkozott=false;
let irany;
let indulas;
let pont=0;
function inditas(event)
{
    if(irany==null && event.key!="ArrowLeft")
    {
        irany=event.key;
    }
    else
    {
        if(irany!=event.key)
        {
            if((irany=="ArrowLeft" && event.key!="ArrowRight") || (irany=="ArrowRight" && event.key!="ArrowLeft") || (irany=="ArrowUp" && event.key!="ArrowDown") || (irany=="ArrowDown" && event.key!="ArrowUp"))
            {
                irany=event.key;
            }
        }
    }
    clearInterval(indulas);
    indulas=setInterval(mozgas,215);
}

function mozgas()
{
    let kigyo=document.getElementById("kigyo");
    let kaja=document.getElementById("kaja");
    let x=parseInt(kigyo.getAttribute("x"));
    let y=parseInt(kigyo.getAttribute("y"));
    let kaja_x=parseInt(kaja.getAttribute("x"));
    let kaja_y=parseInt(kaja.getAttribute("y"));
    let lepes=50;
    if(!utkozott)
    {
        document.getElementById("hely").innerHTML=x+","+y+"<br>";
        if(irany=="ArrowLeft")
        {
            x-=lepes;
            if(x==kaja_x-10 && y==kaja_y)
            {
                let hely_y=Math.round(Math.random()*650);
                let hely_x=Math.round(Math.random()*750);
                while(hely_y%10!=0 && hely_x%10!=0)
                {
                    hely_y=Math.round(Math.random()*650);
                    hely_x=Math.round(Math.random()*750);
                }
                kaja.setAttribute("x",hely_x);
                kaja.setAttribute("y",hely_y);
            }
            kigyo.setAttribute("href","leftmouth.gif");
            kigyo.setAttribute("x",x);
        }

        if(irany=="ArrowRight")
        {
            x+=lepes;
            kigyo.setAttribute("href","rightmouth.gif");
            kigyo.setAttribute("x",x);
        }

        if(irany=="ArrowUp")
        {
            y-=lepes;
            kigyo.setAttribute("href","upmouth.gif");
            kigyo.setAttribute("y",y);
        }

        if(irany=="ArrowDown")
        {
            y+=lepes;
            kigyo.setAttribute("href","downmouth.gif");
            kigyo.setAttribute("y",y);
        }

        if(x==kaja_x-10 && y==kaja_y)
        {
            pont++;
            let hely_y=Math.round(Math.random()*650);
            let hely_x=Math.round(Math.random()*750);
            while(hely_y%50!=0 || hely_x%50!=0)
            {
                hely_y=Math.round(Math.random()*650);
                hely_x=Math.round(Math.random()*750);
            }
            kaja.setAttribute("x",hely_x+10);
            kaja.setAttribute("y",hely_y);
            document.getElementById("pont").innerHTML=pont;
        }
        
        if(x<0 || x>750 || y<0 || y>650)
        {
            if(irany=="ArrowRight")
            {
                x-=lepes;
                kigyo.setAttribute("x",x);
            }
            if(irany=="ArrowLeft")
            {
                x+=lepes;
                kigyo.setAttribute("x",x);
            }
            if(irany=="ArrowDown")
            {
                y-=lepes;
                kigyo.setAttribute("y",y);
            }
            if(irany=="ArrowUp")
            {
                y+=lepes;
                kigyo.setAttribute("y",y);
            }
            utkozott=true;
            alert("Vége")
        }
    }
}