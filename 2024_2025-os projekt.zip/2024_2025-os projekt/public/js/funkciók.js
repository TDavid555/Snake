let irany;
let indulas;
let utkozott=false;
let uj_irany;
let indulhat=false;
let test = [];
let fejMozgasok = [];
let pont=0;
let ido;
let sebesseg=130;
let kategoria="sebesség";
let nehezseg="normál";

function Inditas(valasztas)
{
    let kigyo=document.getElementById("kigyo");
    let kaja=document.getElementById("kaja");
    let testek=document.getElementsByClassName("test");
    switch(valasztas)
    {
        case "indítás":
            document.getElementById("menu").classList.replace("d-block","d-none");
            document.getElementById("navigacio").classList.replace("d-block","d-none");
            document.getElementById("toltokep").classList.replace("d-none","d-block");
            switch(nehezseg)
            {
                case "könnyű":
                    sebesseg=180;
                    break;
                case "normál":
                    sebesseg=130;
                    break;
                case "nehéz":
                    sebesseg=80;
                    break;
            }
            setTimeout(Betoltes,5350);
            indulhat=false;
            break;
        case "beállítások":
            document.getElementById("menu").classList.replace("d-block","d-none");
            document.getElementById("beallitas").classList.replace("d-none","d-block");
            break;
        case "újraindítás":
            document.getElementById("vege").classList.replace("d-block","d-none");
            document.getElementById("navigacio").classList.replace("d-block","d-none");
            document.getElementById("toltokep").classList.replace("d-none","d-block");
            kigyo.setAttribute("x",150);
            kigyo.setAttribute("y",300);
            kigyo.setAttribute("href","Képek/rightmouth.gif");
            kaja.setAttribute("x",660);
            kaja.setAttribute("y",300);
            irany=null;
            uj_irany=null;
            indulhat=false;
            fejMozgasok.splice(0,fejMozgasok.length);
            test.splice(0,test.length);
            testek=document.getElementsByClassName("test");
            while(testek.length>0)
            {
                testek[0].remove();
            }
            pont=0;
            document.getElementById("pont").innerHTML=pont;
            switch(nehezseg)
            {
                case "könnyű":
                    sebesseg=180;
                    break;
                case "normál":
                    sebesseg=130;
                    break;
                case "nehéz":
                    sebesseg=80;
                    break;
            }
            setTimeout(Betoltes,5350);
            break;
        case "lista":
            document.getElementById("menu").classList.replace("d-block","d-none");
            document.getElementById("ranglista").classList.replace("d-none","d-block");
            break;
        case "vissza_r":
            document.getElementById("ranglista").classList.replace("d-block","d-none");
            document.getElementById("menu").classList.replace("d-none","d-block");
            break;
        case "vissza_b":
            document.getElementById("beallitas").classList.replace("d-block","d-none");
            document.getElementById("menu").classList.replace("d-none","d-block");
            break;
        case "vissza_m":
            kigyo=document.getElementById("kigyo");
            kaja=document.getElementById("kaja");
            kigyo.setAttribute("x",150);
            kigyo.setAttribute("y",300);
            kigyo.setAttribute("href","Képek/rightmouth.gif");
            kaja.setAttribute("x",660);
            kaja.setAttribute("y",300);
            irany=null;
            uj_irany=null;
            indulhat=false;
            fejMozgasok.splice(0,fejMozgasok.length);
            test.splice(0,test.length);
            while(testek.length>0)
            {
                testek[0].remove();
            }
            pont=0;
            document.getElementById("pont").innerHTML=pont;
            document.getElementById("vege").classList.replace("d-block","d-none");
            document.getElementById("menu").classList.replace("d-none","d-block");
            break;
    }
}

function Betoltes()
{
    document.getElementById("navigacio").classList.replace("d-none","d-block");
    document.getElementById("toltokep").classList.replace("d-block","d-none");
    indulhat=true;
    Mozgas();
}

window.onkeydown=function(event)
{
    if(indulhat)
    {
        if(event.key=="ArrowLeft" || event.key=="ArrowRight" || event.key=="ArrowDown" || event.key=="ArrowUp")
        {
            if(!irany)
            {
                if(event.key=="ArrowUp" || event.key=="ArrowRight" || event.key=="ArrowDown")
                {
                    irany=event.key;
                }
            }
            else
            {
                uj_irany=event.key;
            }
        }
    }
}

function Mozgas()
{
    
    if(irany!=uj_irany && uj_irany!=undefined)
    {
        if((irany=="ArrowLeft" && uj_irany!="ArrowRight") || (irany=="ArrowRight" && uj_irany!="ArrowLeft") || (irany=="ArrowUp" && uj_irany!="ArrowDown") || (irany=="ArrowDown" && uj_irany!="ArrowUp"))
        {
            irany=uj_irany;
        }
    }
    let kigyo=document.getElementById("kigyo");
    let kigyo_hely={x:parseInt(kigyo.getAttribute("x")),y:parseInt(kigyo.getAttribute("y"))};
    let kaja = document.getElementById("kaja");
    let kaja_hely={x:parseInt(kaja.getAttribute("x")),y:parseInt(kaja.getAttribute("y"))};
    let lepes=50;
    utkozott=Utkozes(kigyo_hely,lepes);
    Nezes(kigyo);
    if(!utkozott)
    {
        fejMozgasok.unshift(kigyo_hely);
        switch(irany)
        {
            case "ArrowLeft":
                kigyo_hely.x-=lepes;
                break;
            case "ArrowRight":
                kigyo_hely.x+=lepes;
                break;
            case "ArrowDown":
                kigyo_hely.y+=lepes;
                break;
            case "ArrowUp":
                kigyo_hely.y-=lepes;
                break;
        }
        for (let i = 0; i < test.length; i++) 
        {
            test[i].setAttribute("x", fejMozgasok[i+1].x);
            test[i].setAttribute("y", fejMozgasok[i+1].y);
        }
        kigyo.setAttribute("x",kigyo_hely.x);
        kigyo.setAttribute("y",kigyo_hely.y);

        if (kigyo_hely.x == kaja_hely.x - 10 && kigyo_hely.y == kaja_hely.y) 
        {
            pont++;
    
            //+testrész
            let testResz = document.createElementNS("http://www.w3.org/2000/svg", "image");
            testResz.setAttribute("href", "Képek/body.gif");
            testResz.classList.add("test");
            testResz.setAttribute("x",fejMozgasok[test.length+1].x);
            testResz.setAttribute("y",fejMozgasok[test.length+1].y);
            document.getElementById("palya").appendChild(testResz);
            test.push(testResz);
            let uj_hely={x:Math.floor(Math.random()*(Math.floor(800/lepes)+1))*lepes,y:Math.floor(Math.random()*(Math.floor(600/lepes)+1))*lepes};
            let van_e=false;
            for(let i=0;i<test.length;i++)
            {
                let hely={x:parseInt(test[i].getAttribute("x")),y:parseInt(test[i].getAttribute("y"))};
                if(hely.x==uj_hely.x && hely.y==uj_hely.y)
                {
                    van_e=true;
                    break;
                }
            }
            while ((kigyo_hely.x==uj_hely.x && kigyo_hely.y==uj_hely.y) || van_e) 
            {
                uj_hely.y =Math.floor(Math.random()*(Math.floor(600/lepes)+1))*lepes;
                uj_hely.x= Math.floor(Math.random()*(Math.floor(800/lepes)+1))*lepes;
                van_e=false
                for(let i=0;i<test.length;i++)
                {
                    let hely={x:parseInt(test[i].getAttribute("x")),y:parseInt(test[i].getAttribute("y"))};
                    if(hely.x==uj_hely.x && hely.y==uj_hely.y)
                    {
                        van_e=true;
                        break;
                    }
                }
            }
            kaja.setAttribute("x", uj_hely.x + 10);
            kaja.setAttribute("y", uj_hely.y);
            document.getElementById("pont").innerHTML = pont;
        }
        setTimeout(function()
        {
            Mozgas();   
        },sebesseg);
    }
    else
    {
        document.getElementById("vege").classList.replace("d-none","d-block");
        cancelAnimationFrame(indulas);
    }
}

function Utkozes(kigyo_hely,lepes)
{
    if((kigyo_hely.x-lepes<0 && irany=="ArrowLeft") || (kigyo_hely.x+lepes>=850 && irany=="ArrowRight") || (kigyo_hely.y-lepes<0 && irany=="ArrowUp") || (kigyo_hely.y+lepes>=650 && irany=="ArrowDown"))
    {
        return true;
    }
    else
    {
        for(let i=test.length-1;i>=0;i--)
        {
            let x=parseInt(test[i].getAttribute("x"));
            let y=parseInt(test[i].getAttribute("y"));
            if((kigyo_hely.x+lepes==x && irany=="ArrowRight" && kigyo_hely.y==y) || (kigyo_hely.x-lepes==x && irany=="ArrowLeft" && kigyo_hely.y==y) || (kigyo_hely.y+lepes==y && irany=="ArrowDown" && kigyo_hely.x==x) || (kigyo_hely.y-lepes==y && irany=="ArrowUp" && kigyo_hely.x==x))
            {
                return true; 
            }
        }
        return false;
    }
}

function Nezes(kigyo)
{
    switch(irany)
    {
        case "ArrowLeft":
            kigyo.setAttribute("href","Képek/leftmouth.gif");
            break;
        case "ArrowRight":
            kigyo.setAttribute("href","Képek/rightmouth.gif");
            break;
        case "ArrowUp":
            kigyo.setAttribute("href","Képek/upmouth.gif");
            break;
        case "ArrowDown":
            kigyo.setAttribute("href","Képek/downmouth.gif");
    }
}
let elore=true
function belepes_regisztracio()
{
    if(window.innerWidth>1000)
    {
        if(elore)
        {
            document.getElementById("hatter").style.animationName="balra";
            document.getElementById("reg").style.animationName="balra2";
            document.getElementById("be").style.animationName="jobbra2";
            document.getElementById("reg2").style.animationName="balra2";
            document.getElementById("be2").style.animationName="jobbra2";
            document.getElementById("reg2").classList.add("d-none")
            document.getElementById("be2").classList.replace("d-none","d-block");
            elore=false;
        }
        else
        {
            document.getElementById("hatter").style.animationName="jobbra";
            document.getElementById("be").style.animationName="jobbra3";
            document.getElementById("reg").style.animationName="balra3";
            document.getElementById("be2").style.animationName="jobbra3";
            document.getElementById("reg2").style.animationName="balra3";
            document.getElementById("be2").classList.add("d-none")
            document.getElementById("reg2").classList.replace("d-none","d-block");
            elore=true;
        }
    }
    else
    {
        if(elore)
        {
            document.getElementById("hatter").style.animationName="fel";
            document.getElementById("reg").style.animationName="fel2";
            document.getElementById("be").style.animationName="le2";
            document.getElementById("reg2").style.animationName="fel2";
            document.getElementById("be2").style.animationName="le2";
            document.getElementById("reg2").classList.add("d-none")
            document.getElementById("be2").classList.replace("d-none","d-block");
            elore=false;
        }
        else
        {
            document.getElementById("hatter").style.animationName="le";
            document.getElementById("be").style.animationName="fel3";
            document.getElementById("reg").style.animationName="le3";
            document.getElementById("be2").style.animationName="fel3";
            document.getElementById("reg2").style.animationName="le3";
            document.getElementById("be2").classList.add("d-none")
            document.getElementById("reg2").classList.replace("d-none","d-block");
            elore=true;
        }

    }
}

async function Regisztracio()
{
    let email=document.getElementById("email");
    let felhasznalonev=document.getElementById("felhasznalonev_r");
    let jelszo=document.getElementById("jelszo_r");
    let jelszo_i=document.getElementById("jelszo_i");
    let kukac_hely=email.value.indexOf("@");
    let pont_hely=email.value.indexOf(".");
    let kukac_darab=0;
    let pont_darab=0;
    for(let i=0;i<email.value.length;i++)
    {
        if(email.value[i]=="@")
        {
            kukac_darab++;
        }

        if(email.value[i]==".")
        {
            pont_darab++;
        }
    }
    let jo_email=true;
    if(kukac_darab!=1 || pont_darab!=1 || kukac_hely>pont_hely || kukac_hely-pont_hely==1 || kukac_hely==0 || pont_hely==email.value.length-1 || email.value.includes(" "))
    {
        email.classList.remove("is-valid");
        email.classList.add("is-invalid");
        jo_email=false;
    }
    else
    {
        email.classList.remove("is-invalid");
        email.classList.add("is-valid");
    }
    let jo_felhasznalonev=true;
    if(felhasznalonev.value.trim()=="")
    {
        felhasznalonev.classList.remove("is-valid");
        felhasznalonev.classList.add("is-invalid");
        jo_felhasznalonev=false;
    }
    else
    {
        const response = await fetch('/ellenorzes',
        {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams({felhasznalonev:felhasznalonev.value})   
        });
        const felhasznalo = await response.json();
        if(felhasznalo.length!=0)
        {
            jo_felhasznalonev=false;
            felhasznalonev.classList.remove("is-valid");
            felhasznalonev.classList.add("is-invalid");
        }
        else
        {
            jo_felhasznalonev=true;
            felhasznalonev.classList.remove("is-invalid");
            felhasznalonev.classList.add("is-valid");
        }
    }

    let szamok=/[0-9]/g;
    let nagybetu=/[A-Z]/g;
    let kisbetu=/[a-z]/g;
    let jo_jelszo=true;
    if(!jelszo.value.match(szamok) || !jelszo.value.match(nagybetu) || !jelszo.value.match(kisbetu))
    {
        jelszo.classList.remove("is-valid");
        jelszo.classList.add("is-invalid");
        jo_jelszo=false;
    }
    else
    {
        jelszo.classList.remove("is-invalid");
        jelszo.classList.add("is-valid");
    }
    let jo_jelszo_i=false
    if(jelszo_i.value==jelszo.value)
    {
        jelszo_i.classList.remove("is-invalid");
        jelszo_i.classList.add("is-valid");
        jo_jelszo_i=true;
    }
    else
    {
        jelszo_i.classList.remove("is-valid");
        jelszo_i.classList.add("is-invalid");   
    }

    if(jo_email && jo_felhasznalonev && jo_jelszo && jo_jelszo_i)
    {
        let kuldes=document.getElementById("reg");
        kuldes.submit();
    }
}

function mutasd_j(szo)
{
    if(szo=="be")
    {
        let jelszo=document.getElementById("jelszo_b");
        let mutasd_j=document.getElementById("mutasd_j_b");
        if(jelszo.type==="password")
        {
            jelszo.type="text";
            mutasd_j.classList.replace("bi-eye-fill","bi-eye-slash-fill")
        }
        else
        {
            jelszo.type="password";
            mutasd_j.classList.replace("bi-eye-slash-fill","bi-eye-fill")
        }
    }

    if(szo=="re")
    {
        let jelszo=document.getElementById("jelszo_r");
        let mutasd_j=document.getElementById("mutasd_j_r");
        if(jelszo.type==="password")
        {
            jelszo.type="text";
            mutasd_j.classList.replace("bi-eye-fill","bi-eye-slash-fill")
        }
        else
        {
            jelszo.type="password";
            mutasd_j.classList.replace("bi-eye-slash-fill","bi-eye-fill")
        }
    }
}

function mutasd_j_i()
{
    let jelszo=document.getElementById("jelszo_i");
    let mutasd_j=document.getElementById("mutasd_j_i");
    if(jelszo.type=="password")
    {
        jelszo.type="text";
        mutasd_j.classList.replace("bi-eye-fill","bi-eye-slash-fill");
    }
    else{
        jelszo.type="password";
        mutasd_j.classList.replace("bi-eye-slash-fill","bi-eye-fill");
    }
}

async function Kod_ellenorzes()
{
    let kod=document.getElementById("kod");
    const response = await fetch('/kod',
    {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({kod:kod.value})   
    });
    const jo_e = await response.text();
    if(jo_e!="egyezik")
    {
        kod.classList.remove("is-valid");
        kod.classList.add("is-invalid");
    }
    else
    {
        kod.classList.remove("is-invalid");
        kod.classList.add("is-valid");
        let kuldes=document.getElementById("ellenorzes");
        kuldes.submit();
    }
}

async function Bejelentkezes() 
{
    let felhasznalonev=document.getElementById("felhasznalonev_b");
    let jelszo=document.getElementById("jelszo_b");
    const response = await fetch('/bejelentkezes',
    {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({felhasznalonev:felhasznalonev.value,jelszo:jelszo.value})   
    });
    const eredmeny=await response.json();
    if(eredmeny.length==0)
    {
        felhasznalonev.classList.remove("is-valid");
        jelszo.classList.remove("is-valid");
        felhasznalonev.classList.add("is-invalid");
        jelszo.classList.add("is-invalid");
    }
    else
    {
        felhasznalonev.classList.remove("is-invalid");
        jelszo.classList.remove("is-imvalid");
        felhasznalonev.classList.add("is-valid");
        jelszo.classList.add("is-valid");
        let kuldes=document.getElementById("be");
        kuldes.submit();
    }
}

async function Kijelentkezes() 
{
    const response = await fetch('/kijelentkezes');
    location.reload();   
}

async function Belepes() 
{
    const response = await fetch('/belepes');
    const eredmeny=await response.json();
    if(eredmeny!=null)
    {
        document.getElementById("nev").innerHTML=eredmeny.felhasználónév;
    }
}

async function Mentes() 
{
    let felhasznalonev=document.getElementById("nev");
    let pont=document.getElementById("pont");
    const response=await fetch("/mentes",
    {
        method:"POST",
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({felhasznalonev:felhasznalonev.innerText,pont:pont.innerText,kategoria:kategoria,nehezseg:nehezseg})
    });
    alert(await response.text())
}

function Beallitasok()
{
    let kategoria_v=document.getElementById("kategoria").value; 
    let nehezseg_v=document.getElementById("nehezseg").value;
    if(kategoria_v=="0" || nehezseg_v=="0")
    {
        alert("Sikertelen mentés");
    }
    else
    {
        alert("Sikeres mentés");
        kategoria=kategoria_v;
        nehezseg=nehezseg_v;
    }
}

function Valasztas(id)
{
    let valasztas=document.getElementById(id);
    valasztas.value=valasztas.options[valasztas.selectedIndex].value
}

async function Listazas() 
{
    let kategoria=document.getElementById("kategoria_l").value;
    let nehezseg=document.getElementById("nehezseg_l").value;
    const response=await fetch("/listazas",
    {
        method:"POST",
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({kategoria:kategoria,nehezseg:nehezseg})
    });    
}