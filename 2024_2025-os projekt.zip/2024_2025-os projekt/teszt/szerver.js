const express = require('express');
const mysql = require('mysql2');
const bodyParser = require('body-parser');

const alkalmazas = express();
alkalmazas.use(express.static('public'));
alkalmazas.use(bodyParser.urlencoded({ extended: true }));

const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'books'
});

// CRUD műveletek
alkalmazas.post('/add', (req, res) => {
    const { name, price } = req.body;
    connection.query('INSERT INTO products (name, price) VALUES (?, ?)', [name, price], (err) => {
        if (err) return res.send('Hiba történt: ' + err);
        res.send('Sikeres beszúrás');
    });
});

alkalmazas.get('/products', (req, res) => {
    connection.query('SELECT * FROM books', (err, results) => {
        if (err) return res.send('Hiba történt: ' + err);
        res.json(results);
    });
});

alkalmazas.post('/update', (req, res) => {
    const { id, price } = req.body;
    connection.query('UPDATE products SET price = ? WHERE id = ?', [price, id], (err) => {
        if (err) return res.send('Hiba történt: ' + err);
        res.send('Sikeres módosítás');
    });
});

alkalmazas.post('/delete', (req, res) => {
    const { id } = req.body;
    connection.query('DELETE FROM products WHERE id = ?', [id], (err) => {
        if (err) return res.send('Hiba történt: ' + err);
        res.send('Sikeres törlés');
    });
});

alkalmazas.listen(3000, () => {
    console.log('Szerver fut a http://localhost:3000 címen');
});
    